class CardRepository:

    def __init__(self):
        self.Count: int = 0
        self.Cards: list = []

    def check_card(self, card):
        for ca in self.Cards:
            if ca.username == card.username:
                return True
        return False

    def add(self, card):
        if self.check_card(card):
            raise ValueError(f"Card {card.name} already exists!")
        self.Cards.append(card)
        self.Count += 1

    def remove(self, card: str):
        if not card:
            raise ValueError("Card cannot be an empty string!")
        card_instance = [ca for ca in self.Cards if ca.username == card]
        if card_instance:
            card_ins = card_instance[0]
            self.Cards.remove(card_ins)
            self.Count -= 1

    def find(self, name: str):
        is_card_found = [ca for ca in self.Cards if ca.name == name]
        if is_card_found:
            return is_card_found[0]
