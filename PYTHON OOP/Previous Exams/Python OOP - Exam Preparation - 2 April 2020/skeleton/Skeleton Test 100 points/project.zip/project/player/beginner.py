from project.player.player import Player


class Beginner(Player):
    def __init__(self, username):
        super().__init__(username, health=50)

    def take_damage(self, damage_points: int):
        pass
