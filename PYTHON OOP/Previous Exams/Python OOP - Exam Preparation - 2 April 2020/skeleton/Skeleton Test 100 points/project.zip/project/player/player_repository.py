class PlayerRepository:

    def __init__(self):
        self.count: int = 0
        self.players: list = []

    def check_player(self, player):
        for pl in self.players:
            if pl.username == player.username:
                return True
        return False

    def add(self, player):
        if self.check_player(player):
            raise ValueError(f"Player {player.username} already exists!")
        self.players.append(player)
        self.count += 1

    def remove(self, player: str):
        if not player:
            raise ValueError("Player cannot be an empty string!")
        player_instance = [pl for pl in self.players if pl.username == player]
        if player_instance:
            player_ins = player_instance[0]
            self.players.remove(player_ins)
            self.count -= 1

        # NOTE check what should be the string of player -> Not instance or his username

    def find(self, username: str):
        is_player_found = [pl for pl in self.players if pl.username == username]
        if is_player_found:
            return is_player_found[0]


