from project.player.beginner import Beginner


class BattleField:

    @staticmethod
    def fight(attacker, enemy):
        if attacker.is_dead or enemy.is_dead:
            raise ValueError("Player is dead!")
        if isinstance(attacker, Beginner):
            attacker.health += 40
            for card in attacker.card_repository:
                card.damage_points += 30
        if isinstance(enemy, Beginner):
            for card in enemy.card_repository:
                card.damage_points += 30

        attacker_bonus_points = sum([card.health_points for card in attacker.card_repository])
        attacker.health += attacker_bonus_points
        enemy_bonus_points = sum([card.health_points for card in enemy.card_repository])
        enemy.health += enemy_bonus_points



